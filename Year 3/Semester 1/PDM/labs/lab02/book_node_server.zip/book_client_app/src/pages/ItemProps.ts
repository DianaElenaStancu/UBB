export interface ItemProps {
    _id?: string;
    name: string;
    pageCount: number;
    dateAdded: Date;
    alreadyRead: Boolean;
}