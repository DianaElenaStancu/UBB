export const mapsApiKey = 'AIzaSyA5B1HrDuuJI48xyvGTljloMtmsvgFOFxo';
