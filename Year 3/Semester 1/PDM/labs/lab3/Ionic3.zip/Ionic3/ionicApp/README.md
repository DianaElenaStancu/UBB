# IonicLab

## App features:

### This application is suitable for displaying the songs in a playlist. The following features are available for the user:

- Show list of songs (id: number, title: string, artist: string, duration: number, hasFeaturedAttributes: boolean) from the playlist
- Edit song title and/or duration
- Add new song to playlist
- Receive WS server notifications
