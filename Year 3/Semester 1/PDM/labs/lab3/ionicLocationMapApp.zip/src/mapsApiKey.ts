export const mapsApiKey = 'add your maps api key here';
