Changelog

01 Sensor list
02 Proximity sensor
