package com.ilazar.mysensorsapp.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xff4b0082)
val Purple500 = Color(0xff4b0082)
val Purple700 = Color(0xff4b0082)
val Teal200 = Color(0xff4b0082)