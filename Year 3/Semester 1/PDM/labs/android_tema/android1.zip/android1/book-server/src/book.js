import Router from 'koa-router';
import dataStore from 'nedb-promise';
import { broadcast } from './wss.js';

export class BookStore {
    // constructor({id, title, writer, date_written, version}) {
    //     this.id = id;
    //     this.title = title;
    //     this.writer = writer;
    //     this.date_written = date_written;
    //     this.version = version;
    // }
    constructor({ filename, autoload }) {
        this.store = dataStore({ filename, autoload });
    }

    async find(props) {
        return this.store.find(props);
    }

    async findOne(props) {
        return this.store.findOne(props);
    }

    async insert(book) {
        if (!book.title || !book.writer) { // validation
            throw new Error('Missing properties')
        }
        return this.store.insert(book);
    };

    async update(props, book) {
        return this.store.update(props, book);
    }

    async remove(props) {
        return this.store.remove(props);
    }
}

const bookStore = new BookStore({ filename: './db/books.json', autoload: true });

export const bookRouter = new Router();

bookRouter.get('/', async (ctx) => {
    const userId = ctx.state.user._id;
    ctx.response.body = await bookStore.find({ userId });
    ctx.response.status = 200; // ok
});

bookRouter.get('/:id', async (ctx) => {
    const userId = ctx.state.user._id;
    const book = await noteStore.findOne({ _id: ctx.params.id });
    const response = ctx.response;
    if (book) {
        if (book.userId === userId) {
            ctx.response.body = book;
            ctx.response.status = 200; // ok
        } else {
            ctx.response.status = 403; // forbidden
        }
    } else {
        ctx.response.status = 404; // not found
    }
});

const createBook = async (ctx, book, response) => {
    try {
        const userId = ctx.state.user._id;
        delete book._id
        book.userId = userId;
        response.body = await bookStore.insert(book);
        console.log(response.body)
        response.status = 201; // created
        broadcast(userId, { type: 'created', payload: book });
    } catch (err) {
        response.body = { message: err.message };
        response.status = 400; // bad request
    }
};

bookRouter.post('/', async ctx => await createBook(ctx, ctx.request.body, ctx.response));

bookRouter.put('/:id', async ctx => {
    const book = ctx.request.body;
    const id = ctx.params.id;
    const bookId = book._id;
    const response = ctx.response;
    if (bookId && bookId !== id) {
        response.body = { message: 'Param id and body _id should be the same' };
        response.status = 400; // bad request
        return;
    }
    if (!bookId) {
        await createItem(ctx, book, response);
    } else {
        const userId = ctx.state.user._id;
        book.userId = userId;
        const updatedCount = await bookStore.update({ _id: id }, book);
        if (updatedCount === 1) {
            response.body = book;
            response.status = 200; // ok
            broadcast(userId, { type: 'updated', payload: book });
        } else {
            response.body = { message: 'Resource no longer exists' };
            response.status = 405; // method not allowed
        }
    }
});

bookRouter.del('/:id', async (ctx) => {
    const userId = ctx.state.user._id;
    const book = await bookStore.findOne({ _id: ctx.params.id });
    if (book && userId !== book.userId) {
        ctx.response.status = 403; // forbidden
    } else {
        await bookStore.remove({ _id: ctx.params.id });
        ctx.response.status = 204; // no content
    }
});
