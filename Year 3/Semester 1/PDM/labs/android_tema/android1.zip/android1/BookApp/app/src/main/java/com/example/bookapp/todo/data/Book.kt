package com.example.bookapp.todo.data

data class Book(
    val _id: String = "",
    val title: String = "",
    val writer: String = "",
//    val date_written:
//    val version
)
