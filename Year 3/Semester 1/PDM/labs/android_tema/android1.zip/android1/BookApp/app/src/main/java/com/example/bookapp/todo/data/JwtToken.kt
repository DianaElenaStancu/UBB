package com.example.bookapp.todo.data

data class JwtToken(
    val token: String = ""
)
