package com.example.bookapp.auth.data.remote

data class TokenHolder(
    val token: String
)
