package com.example.bookapp.todo.data.remote

interface AuthService {
}