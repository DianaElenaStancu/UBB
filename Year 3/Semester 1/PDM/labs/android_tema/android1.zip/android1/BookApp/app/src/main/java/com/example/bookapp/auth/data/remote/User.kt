package com.example.bookapp.auth.data.remote

data class User(
    val username: String,
    val password: String
)
