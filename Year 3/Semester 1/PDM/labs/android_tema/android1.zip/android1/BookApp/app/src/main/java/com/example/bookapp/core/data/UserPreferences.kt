package com.example.bookapp.core.data

data class UserPreferences(val username: String = "", val token: String = "")
