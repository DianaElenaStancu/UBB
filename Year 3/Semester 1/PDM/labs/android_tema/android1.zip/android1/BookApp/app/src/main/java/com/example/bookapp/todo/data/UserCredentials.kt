package com.example.bookapp.todo.data

data class UserCredentials (
    val id: String = "",
    val username: String = "",
    val password: String = "",
)